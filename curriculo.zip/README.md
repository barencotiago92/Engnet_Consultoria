# Currículo com HTML e CSS

Página de currículo feita só com HTML e CSS (sem JavaScript).

## Como personalizar
1. Abra `index.html` e troque nome, e-mail, links, experiências, formação, habilidades e projetos.
2. A foto está embutida no `index.html` (base64). Para trocar, salve sua foto como `foto.jpg` na mesma pasta e substitua o `src="data:image/..."` por `src="foto.jpg"`.
3. Ajuste cores em `style.css`, na seção `:root`.

## Como publicar
1. Faça o fork do repositório do desafio e suba estes arquivos.
2. No GitHub: **Settings → Pages → Branch: main / root → Save**.
3. Crie uma **Release** (Releases → Draft a new release), anexe o ZIP e envie o link no Google Classroom.

## Extras incluídos
- Layout responsivo (celular, tablet e desktop)
- Contraste de cores alto, foco visível, `aria-label` e `aria-labelledby`
- Links externos com `target="_blank"` e `rel="noopener noreferrer"`
- Validação visual dos links de e-mail, GitHub e LinkedIn feita só com CSS (link fora do padrão aparece riscado)
- Estilo de impressão para salvar em PDF
